# Card Beast AR — DR-001 Camera Fix

This version uses `autoStart: false` and a visible `START CAMERA` button.
MindAR is started only after a user gesture, which makes Android camera permission behavior easier to diagnose.

Replace the `index.html` in the GitHub repository with this one. Keep `targets.mind` in the root.

Test:
1. Open the HTTPS GitHub Pages URL.
2. Tap START CAMERA.
3. If Android asks for camera permission, choose Allow.
4. Point the rear camera at DR-001.

If permission was previously denied:
Chrome → site/lock icon → Permissions → Camera → Allow → reload.
